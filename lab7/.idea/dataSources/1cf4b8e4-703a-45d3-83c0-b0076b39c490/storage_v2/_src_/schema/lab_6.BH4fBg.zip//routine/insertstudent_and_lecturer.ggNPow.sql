create procedure InsertStudent_and_lecturer(IN last_name_student_in varchar(50), IN first_name_lecturer_in varchar(50))
  BEGIN
	DECLARE msg varchar(50);

  IF NOT EXISTS( SELECT * FROM Student WHERE last_name=last_name_student_in)
  THEN SET msg = 'This last_name is absent';

	ELSEIF NOT EXISTS( SELECT * FROM Lecturer WHERE first_name=first_name_lecturer_in)
		THEN SET msg = 'This Lecturer is absent';

	ELSEIF EXISTS( SELECT * FROM student_and_lecturer
		WHERE student_id = (SELECT student_id FROM Student WHERE last_name=last_name_student_in)
        AND lecturer_id = (SELECT lecturer_id FROM Lecturer WHERE first_name=first_name_lecturer_in)
        )
        THEN SET msg = 'This Student already has this lecturer';

	ELSEIF (SELECT degree FROM Lecturer WHERE first_name=first_name_lecturer_in)
    <= (SELECT COUNT(*) FROM student_and_lecturer WHERE student_id=(SELECT lecturer_id FROM Lecturer WHERE first_name=first_name_lecturer_in) )
    THEN SET msg = 'There are no this Lecturer already';

    ELSE
		INSERT student_and_lecturer (student_id, lecturer_id)
        Value ( (SELECT student_id FROM Lecturer WHERE Surname=last_name_student_in),
			     (SELECT lecturer_id FROM Lecturer WHERE first_name=first_name_lecturer_in) );
		SET msg = 'OK';

	END IF;

	SELECT msg AS msg;

END;

