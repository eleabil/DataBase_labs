create procedure InsertStudent_and_lecturer(IN LastNameStudentIN varchar(25), IN FirstNameLecturerIN varchar(45))
  BEGIN
	DECLARE msg varchar(40);

  -- checks for present Surname
  IF NOT EXISTS( SELECT * FROM Student WHERE last_name=LastNameStudentIN)
  THEN SET msg = 'This last_name is absent';

  -- checks for present Book
	ELSEIF NOT EXISTS( SELECT * FROM Lecturer WHERE first_name=FirstNameLecturerIN)
		THEN SET msg = 'This Lecturer is absent';

  -- checks if there are this combination already
	ELSEIF EXISTS( SELECT * FROM student_and_lecturer
		WHERE student_id = (SELECT student_id FROM Student WHERE last_name=LastNameStudentIN)
        AND lecturer_id = (SELECT lecturer_id FROM Lecturer WHERE first_name=FirstNameLecturerIN)
        )
        THEN SET msg = 'This Student already has this book';

  -- checks whether there is still such a book
	ELSEIF (SELECT degree FROM Lecturer WHERE first_name=FirstNameLecturerIN )
    <= (SELECT COUNT(*) FROM student_and_lecturer WHERE student_id=(SELECT lecturer_id FROM Lecturer WHERE first_name=FirstNameLecturerIN) )
    THEN SET msg = 'There are no this Lecturer already';

    -- makes insert
    ELSE
		INSERT student_and_lecturer (student_id, lecturer_id)
        Value ( (SELECT student_id FROM Lecturer WHERE Surname=LastNameStudentIN),
			     (SELECT lecturer_id FROM Lecturer WHERE first_name=FirstNameLecturerIN) );
		SET msg = 'OK';

	END IF;

	SELECT msg AS msg;

END;

